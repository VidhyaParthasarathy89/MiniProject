package resourses;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.*;

public class ExcelReader1 {
	
	public static void readExcel() throws IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\Vidhya\\eclipse-workspace\\MiniProjectMain\\TestData\\Data.xlsx");
		XSSFWorkbook workBook = new XSSFWorkbook(fis);
		XSSFSheet sheet = workBook.getSheet("TestData");
		int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
		for(int i=1; i<=rowCount; i++) {
			Row row = sheet.getRow(i);
			for(int j=0; j<row.getLastCellNum(); j++) {
				
				System.out.println(row.getCell(j).getStringCellValue() + " ");
			}
			System.out.println();
		}
	}
	
	public static void main(String[] args) throws IOException {
		readExcel();
	}

}
