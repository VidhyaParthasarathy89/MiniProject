package stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import static org.junit.Assert.*;

import cucumber.api.DataTable;
import cucumber.api.Scenario;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.MMTHomePage;
import resourses.ExcelReader;
import resourses.Utilities;
import resourses.Utilities;

public class HomePageDef extends Utilities{
	MMTHomePage homePage=PageFactory.initElements(driver, MMTHomePage.class);
	
	@When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void i_enter_From_To_Depature_date_Travellers_and_Class_and_click_on_Search(String frmCity, String toCity, String date, String month, int adults, int children, int infants, String tClass) throws Throwable {

		//homePage = PageFactory.initElements(driver, MMTHomePage.class);
		 driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		//Get from city
		homePage.clickFromWidget();
	   
	    homePage.getCity(frmCity, driver);
	    //Get to City
	    homePage.getToCity();
	    
	    homePage.getCity(toCity, driver);
	    homePage.depatureWidget().click();
	    homePage.handleDate(date, month, driver);
	    
	    homePage.clickTravellersAndClass();
	    
	    homePage.selectAdultTravellers(adults, driver);  
	    homePage.selectChildTravellers(children, driver);
	    homePage.selectInfantTravellers(infants, driver);
	    homePage.selectClass(tClass, driver);
	    homePage.selectApply().click();
	}

	@When("^click on search$")
	public void click_on_search() {
		homePage.searchButton().click();
	    
	}
	
	@Then("^List of flights should be displayed$")
	public void list_of_flights_should_be_displayed(){
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		 if(driver.getCurrentUrl().contains("search?")) {
			 Assert.assertTrue(true);
			 
		 }
		
	  // closeTheBrowser();
	}
	
	String beforeSwitchFromCity;
	String beforeSwitchToCity;
	@When("^I enter From and To city$")
	public void i_enter_From_and_To_city(DataTable dt) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<String> list = dt.asList(String.class);
		homePage.clickFromWidget();
	    homePage.getCity(list.get(0).toString(), driver);
	    homePage.getToCity();
	    homePage.getCity(list.get(1).toString(), driver);
	    	}

	@When("^Click on Switch Icon$")
	public void click_on_Switch_Icon() {
		beforeSwitchFromCity = homePage.fromCity.getText();
		beforeSwitchToCity = homePage.toCity.getText();
		waitFor("2");
		homePage.switchButton().click();
	    
	}
	
	@Then("^From and To city switched successfully$")
	public void from_and_To_city_switched_successfully() {
		String afterSwitchFromCity = homePage.fromCity.getText();
		String afterSwitchToCity = homePage.toCity.getText();
		Assert.assertEquals(splitMethod(beforeSwitchFromCity), splitMethod(afterSwitchToCity));
		Assert.assertEquals(splitMethod(beforeSwitchToCity), splitMethod(afterSwitchFromCity));
		//closeTheBrowser();
	    
	}
	
	@Then("^Message regarding discount displayed in return widget$")
	public void message_regarding_discount_displayed_in_return_widget() throws IOException {
		//System.out.println(homePage.getReturnWidgwet().getText());
		//String expectedText = "Tap to add a return date for bigger discounts";
		String actualText = splitMethod(homePage.getReturnWidgwet().getText());
	    Assert.assertEquals(actualText, verifyDiscountText());
	    //closeTheBrowser();
	}

	@When("^Click on Return date widget$")
	public void click_on_Return_date_widget() {
		driver.navigate().refresh();
		homePage.getReturnWidgwet().click();
	    
	}

	@Then("^Ensure Roundtrip radio button selected$")
	public void ensure_Roundtrip_radio_button_selected() {
		waitFor("2");
		Assert.assertFalse(homePage.oneWayTrip().isSelected());
		//Assert.assertTrue(homePage.roundTrip().isSelected());
		//closeTheBrowser();
	}
	ExcelReader e = new ExcelReader();
	ArrayList<String> data;
	@When("^I enter travellers details from excel$")
	public void i_enter_travellers_details_from_excel() throws IOException {
		
		data = e.getData("Search flight for round trip");
		System.out.println("data = "+e.getData("Search flight for round trip"));
		homePage.clickFromWidget();
	    homePage.getCity(data.get(1), driver);
	    homePage.getToCity();
	    homePage.getCity(data.get(2), driver);
	    homePage.depatureWidget().click();
	    homePage.handleDate(data.get(3), data.get(4), driver);
	    homePage.getReturnWidgwet().click();
	    homePage.handleDate(data.get(5), data.get(6), driver);
	    homePage.clickTravellersAndClass();
	    homePage.selectAdultTravellers(Integer.parseInt(data.get(7)), driver);  
	    homePage.selectChildTravellers(Integer.parseInt(data.get(8)), driver);
	    homePage.selectInfantTravellers(Integer.parseInt(data.get(9)), driver);
	    homePage.selectClass(data.get(10), driver);
	    homePage.selectApply().click();
	  
		System.out.println("data = "+e.getData("Search flight for round trip"));
	    
	}
	
	@When("^I enter one way travellers details from excel$")
	public void i_enter_one_way_travellers_details_from_excel() throws IOException {
		data = e.getData("Search flight for round trip");
		System.out.println("data = "+e.getData("Search flight one way trip"));
		homePage.clickFromWidget();
	    homePage.getCity(data.get(1), driver);
	    homePage.getToCity();
	    homePage.getCity(data.get(2), driver);
	    homePage.depatureWidget().click();
	    homePage.handleDate(data.get(3), data.get(4), driver);
	    homePage.clickTravellersAndClass();
	    homePage.selectAdultTravellers(Integer.parseInt(data.get(7)), driver);  
	    homePage.selectChildTravellers(Integer.parseInt(data.get(8)), driver);
	    homePage.selectInfantTravellers(Integer.parseInt(data.get(9)), driver);
	    homePage.selectClass(data.get(10), driver);
	    homePage.selectApply().click();
	  
		System.out.println("data = "+e.getData("Search flight for round trip"));
	  
	}
	
	@When("^I enter number of Adults and number of Infants$")
	public void i_enter_number_of_Adults_and_number_of_Infants(DataTable dt) {
		List<String> list = dt.asList(String.class);
		driver.navigate().refresh();
		homePage.clickTravellersAndClass();
	    homePage.selectAdultTravellers(Integer.parseInt(list.get(0)), driver);  
	    homePage.selectInfantTravellers(Integer.parseInt(list.get(1)), driver);
	    
	}

	@Then("^verify correct error message displayed$")
	public void verify_correct_error_message_displayed() throws IOException {
				String actualMsg = homePage.getErrorMsg().getText();
				if(actualMsg.contains("9")) {
					Assert.assertEquals(verifyErrorForMoretravellers(), actualMsg);
				}else {
					Assert.assertEquals(verifyErrorForMoreInfant(), actualMsg);
				}
	}
	
	@When("^MouseHover on Intromessage and Ensure correct message is displayed$")
	public void mousehover_on_Intromessage_and_Ensure_correct_message_is_displayed() throws IOException {
		try {
		String actualText = getTooltipText(homePage.getIntroTooltip(),homePage.getTooltip());
		String expectedText = verifIntroMsg();
		Assert.assertEquals(expectedText, actualText);
		}catch (Exception e) {
			System.out.println("Functionality not available");
		}
	}
	
	@When("^I enter adults, children and infant count more than nine$")
	public void i_enter_adults_children_and_infant_count_more_than_nine(DataTable dt)  {
	  List<Integer> list = dt.asList(Integer.class);
	  driver.navigate().refresh();
		homePage.clickTravellersAndClass();
	    homePage.selectAdultTravellers(list.get(0), driver);  
	    homePage.selectChildTravellers(list.get(1), driver);
	    homePage.selectInfantTravellers(list.get(2), driver);
	    
	}
	


}
