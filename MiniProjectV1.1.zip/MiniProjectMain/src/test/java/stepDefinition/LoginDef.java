package stepDefinition;

import java.util.List;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;
import pageObject.MMTHomePage;
import pageObject.MMTLoginPage;
import resourses.Utilities;

public class LoginDef extends Utilities{
	MMTLoginPage login;
	
	@Given("^Open the browser and start application$")
	public void open_the_browser_and_start_application() throws Throwable {
		driver = initializeDriver();
		login = PageFactory.initElements(driver, MMTLoginPage.class);
	}
	
	@When("^I enter credentials and login$")
	public void i_enter_username_and_password(DataTable dt) throws Throwable {
		
		List<String> list = dt.asList(String.class);
		login.enterLoginDetails(list.get(0).toString(), list.get(1).toString());
		login.clickLoginButton();
	/*   login.clickLoginButton();
		List<String> list = dt.asList(String.class);
		login.getUsername().sendKeys(list.get(0));
		login.getContinue().click();
		System.out.println(list.get(1));
		login.getPassword().sendKeys(list.get(1)); */
	   
	}
	
}
