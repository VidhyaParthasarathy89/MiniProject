package pageObject;



import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import cucumber.api.java.After;
import resourses.Utilities;

public class MMTHomePage extends Utilities{
	
	public WebDriver driver;
	public MMTHomePage(WebDriver driver) {
		this.driver = driver;
		this.driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox searchCity inactiveWidget')]//label")
	public
	WebElement fromCity;
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox searchToCity inactiveWidget')]//label")
	public
	WebElement toCity;   
	
	@FindBy(xpath = "//input[@id='fromCity']")
	public
	WebElement fromCityName;
	
	@FindBy(xpath = "//input[@id='toCity']")
	public
	WebElement toCityName;
	
	@FindBy(xpath = "//ul[@class = 'react-autosuggest__suggestions-list']/li/div/div/p")
	List<WebElement> cityList;
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox dates inactiveWidget')]")
	WebElement departure;
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox dates inactiveWidget')]//label")
	WebElement depatureDate;
	
	@FindBy(xpath = "//div[contains(@class,'fsw_inputBox dates reDates inactiveWidget')]")
	WebElement returnWidget;
	
	@FindBy(xpath = "//span[@class='DayPicker-NavButton DayPicker-NavButton--next']")
	WebElement navButton;
	
	@FindBy(css = ".DayPicker-Caption")
	WebElement selectMonth;
	
	@FindBy(css = ".DayPicker-Day")
	List<WebElement> selectDay;
	
	@FindBy(css = "div[data-cy='flightTraveller'] [class='lbl_input latoBold appendBottom10']")
	WebElement selectTravellersAndClass;
	
	@FindBy(xpath = "//div[@class='travellers']/div[@class='appendBottom20']/ul[1]")
	WebElement adultTravellers;
	
	@FindBy(xpath = "//div[@class='travellers']/div[@class='appendBottom20']/div[contains(@class, 'makeFlex appendBottom25')]")
	WebElement childAndInfantTravellers;
	
	@FindBy(xpath = "//div[@class='travellers']/div[@class='appendBottom20']/ul[2]")
	WebElement selectTravelClass;
	
	@FindBy(xpath = "//button[@data-cy='travellerApplyBtn']")
	WebElement applyButton;
	
	@FindBy(xpath="//p[@data-cy='submit']/a")
	WebElement search;
	
	@FindBy(xpath = "//span[@class='landingSprite swipIcon']")
	WebElement switchButton;
	
	@FindBy(xpath = "//li[@data-cy='roundTrip']")
	WebElement roundTrip;

	
	public void getToCity() {
		explicitWait(toCity);
		callJavaScriptExecutor(toCity,driver);
	}
	
	public WebElement depatureWidget() {
		return departure;
	}
	
	public WebElement getDepatureDate() {
		return depatureDate;
	}
	
	public WebElement getReturnWidgwet() {
		return returnWidget;
	}
	
	public void getFromCity() { 
		driver.navigate().refresh();
		explicitWait(fromCity);
		//waitFor("3");
		callJavaScriptExecutor(fromCity,driver);
		
	}
	public void getCityList(String city, WebDriver driver) {
		List<WebElement> options = cityList;
		for(WebElement option: options) {
			if(option.getText().startsWith(city)) {
				callJavaScriptExecutor(option,driver);
				break;
			}
			
		}
	}
	
	public void handleDate(String date, String month, WebDriver driver) {
		while(!selectMonth.getText().contains(month)) {
			System.out.println(selectMonth.getText());
			navButton.click();
			}
		
		List<WebElement> dates = selectDay;
		for(WebElement date1: dates) {
			if(date1.getText().startsWith(date)) {
				
				date1.click();
				break;
			}
		}
	}
	
	public void gettravellersAndClass() {
		WebElement loc = selectTravellersAndClass;
		callJavaScriptExecutor(loc,driver);
	}
	
	public void selectAdultTravellers(int adults, WebDriver driver) {
		adultTravellers.findElement(By.xpath("./li["+adults+"]")).click();	
	} 
	
	public void selectChildTravellers(int children, WebDriver driver) {
		int child = children+1;
		childAndInfantTravellers.findElement(By.xpath("./div[1]/ul/li["+child+"]")).click();
	}
	
	public void selectInfantTravellers(int infants, WebDriver driver) {
		int infant = infants+1;
		childAndInfantTravellers.findElement(By.xpath("./div[2]/ul/li["+infant+"]")).click();
	}
	
	public void selectClass(String travelClass, WebDriver driver) {
		if(travelClass.equalsIgnoreCase("Economy/Premium Economy")) {
			selectTravelClass.findElement(By.xpath("./li[1]")).click();
		}else if(travelClass.equalsIgnoreCase("Premium Economy")) {
			selectTravelClass.findElement(By.xpath("./li[2]")).click();;
		}else if(travelClass.equalsIgnoreCase("Business")) {
			selectTravelClass.findElement(By.xpath("./li[3]")).click();
		}
		
	}
	
	public WebElement selectApply() {
		return applyButton;
	}
	
	public WebElement searchButton() {
		return search;
	}
	
	public WebElement switchButton() {
		return switchButton;
	}
	
	public WebElement roundTrip() {
		return roundTrip;
	}

}
