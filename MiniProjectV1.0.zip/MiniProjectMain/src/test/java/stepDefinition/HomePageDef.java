package stepDefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.support.PageFactory;
import static org.junit.Assert.*;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageObject.MMTHomePage;
import resourses.Utilities;
import resourses.Utilities;

public class HomePageDef extends Utilities{
	MMTHomePage homePage=PageFactory.initElements(driver, MMTHomePage.class);
	
	@When("^I enter \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
	public void i_enter_From_To_Depature_date_Travellers_and_Class_and_click_on_Search(String frmCity, String toCity, String date, String month, int adults, int children, int infants, String tClass) throws Throwable {

		//homePage = PageFactory.initElements(driver, MMTHomePage.class);
		 driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		//Get from city
		homePage.getFromCity();
	   
	    homePage.getCityList(frmCity, driver);
	    //Get to City
	    homePage.getToCity();
	    
	    homePage.getCityList(toCity, driver);
	    homePage.depatureWidget().click();
	    homePage.handleDate(date, month, driver);
	    
	    homePage.gettravellersAndClass();
	    
	    homePage.selectAdultTravellers(adults, driver);  
	    homePage.selectChildTravellers(children, driver);
	    homePage.selectInfantTravellers(infants, driver);
	    homePage.selectClass(tClass, driver);
	    homePage.selectApply().click();
	}

	@When("^click on search$")
	public void click_on_search() {
		homePage.searchButton().click();
	    
	}
	
	@Then("^List of flights should be displayed$")
	public void list_of_flights_should_be_displayed(){
		driver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
		 if(driver.getCurrentUrl().contains("search?")) {
			 Assert.assertTrue(true);
			 
		 }
		
	   closeTheBrowser();
	}
	
	String beforeSwitchFromCity;
	String beforeSwitchToCity;
	@When("^I enter From and To city$")
	public void i_enter_From_and_To_city(DataTable dt) {
	    // Write code here that turns the phrase above into concrete actions
	    // For automatic transformation, change DataTable to one of
	    // List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
	    // E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<String> list = dt.asList(String.class);
		homePage.getFromCity();
	    homePage.getCityList(list.get(0).toString(), driver);
	    homePage.getToCity();
	    homePage.getCityList(list.get(1).toString(), driver);
	    	}

	@When("^Click on Switch Icon$")
	public void click_on_Switch_Icon() {
		beforeSwitchFromCity = homePage.fromCity.getText();
		beforeSwitchToCity = homePage.toCity.getText();
		homePage.switchButton().click();
	    
	}
	
	@Then("^From and To city switched successfully$")
	public void from_and_To_city_switched_successfully() {
		String afterSwitchFromCity = homePage.fromCity.getText();
		String afterSwitchToCity = homePage.toCity.getText();
		String[] a = beforeSwitchFromCity.split("\n");
		String[] c = beforeSwitchToCity.split("\n");
		String[] b = afterSwitchToCity.split("\n");
		String[] d = afterSwitchFromCity.split("\n");
		//System.out.println("a = " +a[1] + " "+"b = "+b[1]);
		//System.out.println("c = "+c[1] +" "+"d = "+d[1]);
		Assert.assertEquals(a[1], b[1]);
		Assert.assertEquals(c[1], d[1]);
		closeTheBrowser();
	    
	}
	
	@Then("^Message regarding discount displayed in return widget$")
	public void message_regarding_discount_displayed_in_return_widget() {
		System.out.println(homePage.getReturnWidgwet().getText());
		String actualText = splitMethod(homePage.getReturnWidgwet().getText());
	    Assert.assertEquals(actualText, "Tap to add a return date for bigger discounts");
	    closeTheBrowser();
	}

	@When("^Click on Return date widget$")
	public void click_on_Return_date_widget() {
		driver.navigate().refresh();
		homePage.getReturnWidgwet().click();
	    
	}

	@Then("^Ensure Roundtrip radio button selected$")
	public void ensure_Roundtrip_radio_button_selected() {
		waitFor("2");
		Assert.assertTrue(homePage.roundTrip().isSelected());
		closeTheBrowser();
	}

}
