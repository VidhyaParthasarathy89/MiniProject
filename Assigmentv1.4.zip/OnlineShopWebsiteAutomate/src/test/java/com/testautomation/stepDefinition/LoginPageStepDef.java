package com.testautomation.stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


import com.testautomation.TestRunner.TestRunner1;
import com.testautomation.pages.AddToCartPage;
import com.testautomation.pages.HomePage;
import com.testautomation.pages.LoginPage;
import com.testautomation.pages.ShoppingCartSummaryPage;
import com.testautomation.utility.ExcelDataProvider1;
import com.testautomation.utility.Helper1;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.Scenario;


public class LoginPageStepDef extends TestRunner1{
	
//	LoginPage login;
	@Given("^open the online shop browser and start application$")
	public void open_the_online_shop_browser_and_start_application() {
		 String qaURL = config.getDataFromConfig("qaURL");
		 driver.get(qaURL);
		//	login = PageFactory.initElements(driver, LoginPage.class);
			login.getSignInLink().click();
	    
	}
	ExcelDataProvider1 excel = new ExcelDataProvider1();
	
	@When("^user enter credentials and login$")
	public void user_enter_credentials_and_login() throws IOException {
		//Scenario scenario;
		//System.out.println(scenario.getName());
		//Scenario scenario = CucumberHelper.scenario.getName();
		ArrayList<String> loginData =  excel.getData("Login credentials", "LoginData");
		System.out.println("data = "+loginData);
		login.getUserName().sendKeys(loginData.get(1));
		login.getPassword().sendKeys(loginData.get(2));
		//List<String> list = dt.asList(String.class);
		//login.getUserName().sendKeys(list.get(0).toString());
		//login.getPassword().sendKeys(list.get(1).toString());
		login.getSigninButton().click();
	    
	}
	Helper1 h = new Helper1();
	ArrayList<String> data;
	@When("^user select Women's T-shirt, Qualtity, Size, colour$")
	public void user_select_Women_s_T_shirt_Qualtity_Size_colour() throws IOException {
		data = excel.getData("Select T-Shirt and checkout", "ShoppingData");
		home = PageFactory.initElements(driver, HomePage.class);
		h.mouseHoverAndSelect(driver, home.getWomenLink(), home.selectTShirt());
		h.mouseHoverAndSelect(driver, home.selectFirstTShirt(), home.clickMoreButton());
		Integer quantity = Integer.parseInt(data.get(3));
	//	add = PageFactory.initElements(driver, AddToCartPage.class);
		h.selectQuantity(quantity);
		new Select(add.selectSize()).selectByVisibleText(data.get(4));
		h.selectYourColour(data.get(5));
	    
	}

	@Then("^click on Add to card button and order details displayed and Click on Proceed to checkout$")
	public void click_on_Add_to_card_button_and_order_details_displayed_and_Click_on_Proceed_to_checkout() {
		add.addToCartButton().click();
	    h.waitMethod(add.proceedToCheckout());
		add.proceedToCheckout().click();
	    Assert.assertEquals(add.yourShoppingCartMsg().getText(), "Your shopping cart");
	   // home.logoutButton().click();
	}
	
	@When("^user select Women's T-shirt and mousehover$")
	public void user_select_Women_s_T_shirt_and_mousehover() {
		home = PageFactory.initElements(driver, HomePage.class);
		h.callJavaScriptExecutor(home.getWomenLink(), home.selectTShirt(), driver);
		//h.mouseHoverAndSelect(driver, home.getWomenLink(), home.selectTShirt());
		
		
	}
	
	@Then("^click on Add to wish list and verify error message$")
	public void click_on_Add_to_wish_list_and_verify_error_message() {
		h.callJavaScriptExecutor(home.getWomenLink(), home.addToWishlistButton(), driver);
		Assert.assertEquals(home.errorMessageWishlist().getText(), "You must be logged in to manage your wishlist.");
	}
	
	@When("^user select Women's T-shirt, Qualtity, Size and colour$")
	public void user_select_Women_s_T_shirt_Qualtity_Size_and_colour() throws IOException {
		data = excel.getData("Verify total price", "ShoppingData");
		System.out.println(data);
	//	home = PageFactory.initElements(driver, HomePage.class);
		h.mouseHoverAndSelect(driver, home.getWomenLink(), home.selectTShirt());
		h.mouseHoverAndSelect(driver, home.selectFirstTShirt(), home.clickMoreButton());
		Integer quantity = Integer.parseInt(data.get(3));
		//add = PageFactory.initElements(driver, AddToCartPage.class);
		h.selectQuantity(quantity);
		new Select(add.selectSize()).selectByVisibleText(data.get(4));
		h.selectYourColour(data.get(5));
	}
	

	@When("^change the quantity$")
	public void change_the_quantity() {
		//shop = PageFactory.initElements(driver, ShoppingCartSummaryPage.class);
		//h.waitMethod(shop.increaseQuantity());
		//h.increaseQuantity(Integer.parseInt(data.get(6)));
		System.out.println("quantity = "+data.get(6));
		shop.returnQuantityTextBox().clear();
		shop.returnQuantityTextBox().sendKeys(data.get(6));
	}
	
	@Then("^ensure Total price is changing and reflecting correct price$")
	public void ensure_Total_price_is_changing_and_reflecting_correct_price() throws InterruptedException {
		Thread.sleep(5000);
		Double unitPrice = Double.parseDouble(shop.unitPrice().getText().substring(1));
		System.out.println("unitPrice="+unitPrice);
		//System.out.println("quantity = "+shop.returnQuantity().getText());
		//Integer quantity = Integer.parseInt(shop.returnQuantity().getText());
		//System.out.println(quantity);
		Double expectedPrice =  Integer.parseInt(data.get(6))*unitPrice;
		System.out.println("expectedPrice = "+expectedPrice);
		Double actualPrice = Double.parseDouble(shop.totalPrice().getText().substring(1));
		System.out.println("actualPrice = "+actualPrice);
		Assert.assertEquals(actualPrice, expectedPrice);
	}

}
