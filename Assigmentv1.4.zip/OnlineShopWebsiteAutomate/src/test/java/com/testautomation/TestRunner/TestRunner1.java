package com.testautomation.TestRunner;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.IClass;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.xml.XmlTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.testautomation.pages.AddToCartPage;
import com.testautomation.pages.HomePage;
import com.testautomation.pages.LoginPage;
import com.testautomation.pages.ShoppingCartSummaryPage;
import com.testautomation.utility.BrowserFactory1;
import com.testautomation.utility.ConfigDataProvider1;
import com.testautomation.utility.ExcelDataProvider1;
import com.testautomation.utility.Helper1;

import cucumber.api.CucumberOptions;
import cucumber.api.Scenario;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.PickleEventWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import gherkin.formatter.model.Result;
import gherkin.events.PickleEvent;




@CucumberOptions(
		features = "./features",
		glue = {"com.testautomation.stepDefinition"},
		//tags = {"@Testcase3"},
		plugin = {"pretty", "html:target\\cucumber-reports",
				"json:target/cucumber-reports/cucumber.json",
				"junit:target/cucumber-reports/cucumber.xml",},
					monochrome = true,
		dryRun = false
		)

public class TestRunner1{
	
	public static WebDriver driver;
	public static ConfigDataProvider1 config;
	public static  ExtentReports report;
	public static ExtentTest logger;
	public static String browserName;
	//public static String qaURL;
	private TestNGCucumberRunner testNGCucumberRunner;
	public LoginPage login=PageFactory.initElements(driver, LoginPage.class);
	public HomePage home =PageFactory.initElements(driver, HomePage.class);
	public AddToCartPage add=PageFactory.initElements(driver, AddToCartPage.class);
	public ShoppingCartSummaryPage shop=PageFactory.initElements(driver, ShoppingCartSummaryPage.class);
	
	@BeforeSuite
	public void setUpSuite() {
		Reporter.log("Setting up reports and Test is getting ready.", true);
	//	testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		config = new ConfigDataProvider1();
		browserName= config.getBrowserName();
		//qaURL = config.getQAURL();
		ExtentHtmlReporter extent = new ExtentHtmlReporter(
				new File(System.getProperty("user.dir") + "/Reports/Report_" + Helper1.getCurrentDateTime() + ".html"));
		report = new ExtentReports();
		report.attachReporter(extent);
		Reporter.log("Setting is Done - Test can be started", true);
		
	}
	@BeforeClass
	public void setUpClass() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		
	}
	@BeforeMethod
	//@BeforeTest
	public static void setup() { 
		Reporter.log("Starting the Browser and setting the URL", true);

		driver = BrowserFactory1.startApplication(driver, browserName);

		Reporter.log("Browser started and Can now navigate to application", true);
		//System.out.println("Scenario name = "+m);
	}
		
	@Test(groups = "cucumber scenarios", description = "Runs cucunber scenarios", dataProvider = "scenarios")
	public void scenario(PickleEventWrapper pickleEvent, CucumberFeatureWrapper cucumberFeature) throws Throwable {
		testNGCucumberRunner.runScenario(pickleEvent.getPickleEvent());

	}
	
	@DataProvider
	public Object[][] scenarios(){
		return testNGCucumberRunner.provideScenarios();
	}
	
	/*@AfterClass(alwaysRun=true)
	public void tearDownClass() {
		BrowserFactory1.quitBrrowser(driver);
	}*/
	
	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException {
		 
		Reporter.log("Test is about to Complete >>>> Reports is getting Generated next", true);

		if (result.getStatus() == ITestResult.FAILURE) {
		
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		} else if (result.getStatus() == ITestResult.SKIP) {
			
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		}
		
		report.flush();

		Reporter.log("Test Completed >>>> Reports Generation Completed", true);
		BrowserFactory1.quitBrrowser(driver);
		
	}
	
	/*@AfterTest
	public void tearDown() {
		report.flush();
		
		BrowserFactory1.quitBrrowser(driver);
	}*/
	
	/*@AfterSuite
	public void afterSuite() {
		BrowserFactory1.quitBrrowser(driver);
	}*/
	

}
