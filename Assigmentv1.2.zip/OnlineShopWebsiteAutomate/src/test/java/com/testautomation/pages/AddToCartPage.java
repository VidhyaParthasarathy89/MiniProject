package com.testautomation.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddToCartPage {
	
	@FindBy(xpath="//p[@id='quantity_wanted_p']/a[2]")
	WebElement addQuantity;
	
	@FindBy(xpath="//div[@class='attribute_list']/div//select[@id='group_1']")
	WebElement size;
	
	@FindBy(xpath="//ul[@id='color_to_pick_list']/li")
	List<WebElement> coloursList;
	
	@FindBy(xpath="//p[@id='add_to_cart']/button")
	WebElement addToCart;
	
	public WebElement clickAddQuantity() {
		return addQuantity;
	}
	
	public WebElement selectSize() {
		return size;
	}
	
	public List<WebElement> getColourList() {
		return coloursList;
	}
	
	public WebElement addToCartButton() {
		return addToCart;
	}

}
