package com.testautomation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.testautomation.TestRunner.TestRunner1;

public class LoginPage {

	
	@FindBy(xpath="//div[@class='container']//div[@class='row']/nav/div[1]/a")
	WebElement signIn;
	
	@FindBy(xpath="//form[@id='login_form']/div/div[1]/input")
	WebElement userName;
	
	@FindBy(xpath="//form[@id='login_form']/div/div[2]/span/input")
	WebElement password;
	
	@FindBy(xpath="//button[@id='SubmitLogin']")
	WebElement signinButton;
	
	public WebElement getSignInLink() {
		return signIn;
	}
	
	public WebElement getUserName() {
		return userName;
	}
	
	public WebElement getPassword() {
		return password;
	}
	
	public WebElement getSigninButton() {
		return signinButton;
	}
	
}
