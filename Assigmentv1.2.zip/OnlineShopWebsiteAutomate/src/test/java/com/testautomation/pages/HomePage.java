package com.testautomation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class HomePage {
	
	@FindBy(xpath="//div[@id='block_top_menu']/ul/li[1]")
	WebElement women;
	
	@FindBy(xpath="//div[@id='block_top_menu']/ul/li[1]/ul/li[1]/ul/li[1]/a") ////div[@id='block_top_menu']/ul/li[1]/ul/li[1]/ul/li[1]/a
	WebElement tShirt;
	
	@FindBy(xpath="//a[@class='product_img_link']/img")
	WebElement FirstTshirt;
	
	@FindBy(xpath="//div[@class='button-container']/a[2]")
	WebElement moreButton;
	
	public WebElement getWomenLink() {
		return women;
	}
	
	public WebElement selectTShirt() {
		return tShirt;
	}
	
	public WebElement selectFirstTShirt() {
		return FirstTshirt;
	}
	
	public WebElement clickMoreButton() {
		return moreButton;
	}
	
	

}
