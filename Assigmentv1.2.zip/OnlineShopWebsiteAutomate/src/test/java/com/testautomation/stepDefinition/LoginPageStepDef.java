package com.testautomation.stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;

import com.testautomation.TestRunner.TestRunner1;
import com.testautomation.pages.HomePage;
import com.testautomation.pages.LoginPage;
import com.testautomation.utility.ExcelDataProvider1;
import com.testautomation.utility.Helper1;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class LoginPageStepDef extends TestRunner1{
	
//	LoginPage login;
	@Given("^open the online shop browser and start application$")
	public void open_the_online_shop_browser_and_start_application() {
		 String qaURL = config.getDataFromConfig("qaURL");
		 driver.get(qaURL);
			login = PageFactory.initElements(driver, LoginPage.class);
			login.getSignInLink().click();
	    
	}
	ExcelDataProvider1 excel = new ExcelDataProvider1();
	ArrayList<String> data;
	@When("^user enter credentials and login$")
	public void user_enter_credentials_and_login() throws IOException {
		data =  excel.getData("Login into Testing Web Application", "LoginData");
		System.out.println("data = "+data);
		login.getUserName().sendKeys(data.get(1));
		login.getPassword().sendKeys(data.get(2));
		//List<String> list = dt.asList(String.class);
		//login.getUserName().sendKeys(list.get(0).toString());
		//login.getPassword().sendKeys(list.get(1).toString());
		login.getSigninButton().click();
	    
	}
	Helper1 h = new Helper1();
	@When("^user select Women's T-shirt, Qualtity, Size, colour and click on Add to card button$")
	public void user_select_Women_s_T_shirt_Qualtity_Size_colour_and_click_on_Add_to_card_button() {
		home = PageFactory.initElements(driver, HomePage.class);
		h.mouseHoverAndSelect(driver, home.getWomenLink(), home.selectTShirt());
		h.mouseHoverAndSelect(driver, home.selectFirstTShirt(), home.clickMoreButton());
		
		
	    
	}

	@Then("^order details displayed and Click on Proceed to checkout$")
	public void order_details_displayed_and_Click_on_Proceed_to_checkout() {
	    
	}

}
