package com.testautomation.TestRunner;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Set;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.IClass;
import org.testng.ITestContext;
import org.testng.ITestNGMethod;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.xml.XmlTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.testautomation.pages.HomePage;
import com.testautomation.pages.LoginPage;
import com.testautomation.utility.BrowserFactory1;
import com.testautomation.utility.ConfigDataProvider1;
import com.testautomation.utility.ExcelDataProvider1;
import com.testautomation.utility.Helper1;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import cucumber.api.testng.CucumberFeatureWrapper;
import cucumber.api.testng.TestNGCucumberRunner;
import gherkin.formatter.model.Result;



@CucumberOptions(
		features = "./features",
		glue = {"com.testautomation.stepDefinition"},
		plugin = {"pretty", "html:target\\cucumber-reports",
				"json:target/cucumber-reports/cucumber.json",
				"junit:target/cucumber-reports/cucumber.xml",},
					monochrome = true
		)

public class TestRunner1 extends AbstractTestNGCucumberTests {
	
	public static WebDriver driver;
	public static ConfigDataProvider1 config;
	public static  ExtentReports report;
	public static ExtentTest logger;
	public static String browserName;
	//public static String qaURL;
	private TestNGCucumberRunner testNGCucumberRunner;
	public LoginPage login;
	public HomePage home;
	
	@BeforeSuite
	public void setUpSuite() {
		Reporter.log("Setting up reports and Test is getting ready.", true);
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
		config = new ConfigDataProvider1();
		browserName= config.getBrowserName();
		//qaURL = config.getQAURL();
		ExtentHtmlReporter extent = new ExtentHtmlReporter(
				new File(System.getProperty("user.dir") + "/Reports/Report_" + Helper1.getCurrentDateTime() + ".html"));
		report = new ExtentReports();
		report.attachReporter(extent);
		Reporter.log("Setting is Done - Test can be started", true);
		
	}
	

	@BeforeTest
	public static void setup() {
		Reporter.log("Starting the Browser and setting the URL", true);

		driver = BrowserFactory1.startApplication(driver, browserName);

		Reporter.log("Browser started and Can now navigate to application", true);
		
	}
	
	@Test(groups = "cucumber", description = "Runs cucumber feature", dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}
	
	@DataProvider
	public Object[][] features(){
		return testNGCucumberRunner.provideFeatures();
	}
	
	@AfterClass(alwaysRun=true)
	public void tearDownClass() {
		testNGCucumberRunner.finish();
	}
	
	/*@Test(groups = "cucumber", dependsOnMethods = "loginToApplication")
	public void selectTShirt() {
		logger = report.createTest("Select TT-Shirt");
		home = PageFactory.initElements(driver, HomePage.class);
		
	}*/
	
	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException {
		 
		Reporter.log("Test is about to Complete >>>> Reports is getting Generated next", true);
		

		if (result.getStatus() == ITestResult.FAILURE) {
		
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		} else if (result.getStatus() == ITestResult.SUCCESS) {
			
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		} else if (result.getStatus() == ITestResult.SKIP) {
			
					MediaEntityBuilder.createScreenCaptureFromPath(Helper1.captureScreenshot(driver)).build();
		}
		
		report.flush();

		Reporter.log("Test Completed >>>> Reports Generation Completed", true);

		
	}
	
	@AfterSuite
	public void tearDown() {
		//report.flush();
		
		BrowserFactory1.quitBrrowser(driver);
	}
	
/*	private TestNGCucumberRunner testNGCucumberRunner;
	@BeforeClass(alwaysRun = true)
	public void setUpClass() {
		testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
	}
	
	@Test(dataProvider = "features")
	public void feature(CucumberFeatureWrapper cucumberFeature) {
		testNGCucumberRunner.runCucumber(cucumberFeature.getCucumberFeature());
	}
	
	@DataProvider
	public Object[][] features(){
		return testNGCucumberRunner.provideFeatures();
	}
	
	@AfterClass(alwaysRun = true)
	public void tearDownClass() {
		testNGCucumberRunner.finish();
	} */
	

}
