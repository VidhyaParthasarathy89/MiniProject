package com.testautomation.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;

public class Helper1 {
	public static String captureScreenshot(WebDriver driver) {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String screenshotName = getCurrentDateTime() + ".png";
		String screenshotPath = System.getProperty("user.dir") + "/Screenshots/" + screenshotName;
		try {

			FileHandler.copy(src, new File(screenshotPath));
			System.out.println("Screenshot Captured with the Name: " + screenshotName);

		} catch (IOException e) {
			System.out.println("Unable to capture screenshot " + e.getMessage());
		}

		return screenshotPath;
	}
	
	public static String getCurrentDateTime() {
		DateFormat customFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date currentDate = new Date();
		return customFormat.format(currentDate).toString();
	}
	
	public void mouseHoverAndSelect(WebDriver driver, WebElement loc1, WebElement loc2) {
		Actions a = new Actions(driver);
		a.moveToElement(loc1);
		a.click(loc2).build().perform();
	}

	
}
