package pageObject;

import java.util.HashMap;

/*public class MyPages {
	private static HashMap<String, Object> hs = new HashMap<String, Object>();
	public static void addObject(String obj1, Object obj2) {
		hs.put(obj1, obj2);
	}
	
	public static Object getPageObject(String pageName) {
		if(hs.containsKey(pageName)) {
			return hs.get(pageName);
		}else {
			return null;
		}
	}
} */
