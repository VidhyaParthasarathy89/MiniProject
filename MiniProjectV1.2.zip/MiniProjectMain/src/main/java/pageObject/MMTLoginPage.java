package pageObject;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;

import resourses.Utilities;

public class MMTLoginPage extends Utilities{
	public WebDriver driver;
	
	@FindBy(xpath = "//p[contains(text(),'Login or Create Account')]")
	WebElement login;
	
	@FindBy(xpath = "//*[@class='rightArrow pushRight']")
	WebElement loginArrowButton;
	
	@CacheLookup
	@FindBy(id = "username")
	WebElement userName;
	
	@CacheLookup
	@FindBy(id = "password")
	WebElement passWord;
	
	@FindBy(xpath="//*[@data-cy='login']")
	WebElement loginButton;
	
	@FindBy(xpath="//div[contains(@class,'btnContainer appendBottom25')]")
	WebElement continueButton;
	
	public WebElement getPassword() {
	return passWord;
}

public WebElement getUsername() {
	return userName;
}


public WebElement getContinue() {
	return continueButton;
}

public WebElement getLoginButton() {
	return loginButton;
} 

	
		public MMTLoginPage(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	public void enterLoginDetails(String username, String password) {
		driver.navigate().refresh();

		try {
			loginArrowButton.click();
		} catch (Exception e) {

		}

		try {
			login.click();
		} catch (Exception e) {

		}

		userName.sendKeys(username);
		continueButton.click();
		passWord.sendKeys(password);

	}

	public void clickLoginButton() {
		if (loginButton.isEnabled()) {
			loginButton.click();
		}
	}
	


	

	/*public void closeTheBrowser() {
		driver.close();
		driver.quit();
	} */

}
