package com.testautomation.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;

import org.apache.commons.math3.analysis.function.Add;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.testautomation.TestRunner.TestRunner1;
import com.testautomation.pages.AddToCartPage;
import com.testautomation.pages.ShoppingCartSummaryPage;

public class Helper1 extends TestRunner1 {
	public static String captureScreenshot(WebDriver driver) {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String screenshotName = getCurrentDateTime() + ".png";
		String screenshotPath = System.getProperty("user.dir") + "/Screenshots/" + screenshotName;
		try {

			FileHandler.copy(src, new File(screenshotPath));
			System.out.println("Screenshot Captured with the Name: " + screenshotName);

		} catch (IOException e) {
			System.out.println("Unable to capture screenshot " + e.getMessage());
		}

		return screenshotPath;
	}
	
	public static String getCurrentDateTime() {
		DateFormat customFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date currentDate = new Date();
		return customFormat.format(currentDate).toString();
	}
	
	public void mouseHoverAndSelect(WebDriver driver, WebElement loc1, WebElement loc2) {
		Actions a = new Actions(driver);
		a.moveToElement(loc1);
		a.click(loc2).build().perform();
	}
	
	public void selectQuantity(Integer n) {
		add = PageFactory.initElements(driver, AddToCartPage.class);
		
		for(int i=1; i<n; i++) {
			add.addQuantity().click();
		
		}
	}
	
	public void selectYourColour(String colour) {
		if(colour.equalsIgnoreCase("orange")) {
			add.getColour().findElement(By.xpath("./li[1]")).click();
		}else if (colour.contentEquals("blue")) {
			add.getColour().findElement(By.xpath("./li[2]")).click();
		}else {
			System.out.println(colour + " colour is not available");
		}
	}
	
	public void waitMethod(WebElement loc) {
		 WebDriverWait wait = new WebDriverWait(driver,30);
			wait.until(ExpectedConditions.elementToBeClickable(loc));
	}
	public void moveToElementAction(WebDriver driver, WebElement loc) {
		Actions a = new Actions(driver);
		a.moveToElement(loc);
	}
	public void callJavaScriptExecutor(WebElement loc1, WebElement loc2, WebDriver driver) {
		moveToElementAction(driver, loc1);
		JavascriptExecutor exe = (JavascriptExecutor)driver;
		exe.executeScript("arguments[0].click();", loc2);
	}
	
	/*public void increaseQuantity(Integer n) {
		System.out.println(n);
		shop = PageFactory.initElements(driver, ShoppingCartSummaryPage.class);
		for(int i=1; i<n; i++) {
			//callJavaScriptExecutor(shop.increaseQuantity(), shop.increaseQuantity(), driver);
			shop.returnquantityTextBox();
		}
	}*/
}
