package com.testautomation.pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class AddToCartPage {
	
	@FindBy(xpath="//p[@id='quantity_wanted_p']/a[2]")
	WebElement addQuantity;
	
	@FindBy(xpath="//div[@class='attribute_list']/div//select[@id='group_1']")
	WebElement size;
	
	@FindBy(xpath="//ul[@id='color_to_pick_list']")
	WebElement coloursList;
	
	@FindBy(xpath="//p[@id='add_to_cart']/button")
	WebElement addToCart;
	
	@FindBy(xpath="//div[@class='clearfix']/div//h2[1]")
	WebElement successMessage;
	
	@FindBy(xpath="//div[@class='button-container']/a")
	WebElement checkOut;
	
	@FindBy(xpath="//span[@class='navigation_page']")
	WebElement yourShoppingCart;
	
	public WebElement addQuantity() {
		return addQuantity;
	}
	
	public WebElement selectSize() {
		return size;
	}
	
	public WebElement getColour() {
		return coloursList;
	}
	
	public WebElement addToCartButton() {
		return addToCart;
	}
	
	public WebElement getSuccessMessage() {
		return successMessage;
	}
	
	public WebElement proceedToCheckout() {
		return checkOut;
	}
	
	public WebElement yourShoppingCartMsg() {
		return yourShoppingCart;
	}
}
