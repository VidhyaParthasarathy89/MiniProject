package com.testautomation.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ShoppingCartSummaryPage {
	
	@FindBy(xpath="//i[@class='icon-plus']")
	WebElement increaseQuantity;
	
	@FindBy(xpath="//td[@class='cart_unit']//span[@class='price']")
	WebElement unitPrice;
	
	@FindBy(xpath="//td[@class='cart_unit']/following-sibling::td[1]/input[2]")
	WebElement quantity;
	
	@FindBy(xpath="//td[@class='cart_total']//span[@class='price']")
	WebElement totalPrice;
	
	@FindBy(xpath="//input[@name='quantity_1_1_0_382679']")
	WebElement quantityTextBox;
	
	public WebElement increaseQuantity() {
		return increaseQuantity;
	}
	
	public WebElement returnQuantity() {
		return quantity;
	}
	
	public WebElement unitPrice() {
		return unitPrice;
	}
	
	public WebElement totalPrice() {
		return totalPrice;
	}
	
	public WebElement returnQuantityTextBox() {
		return quantityTextBox;
	}
}
