package pageObject;

/*public class Pages {
	
	public static MMTLoginPage mmtLoginPage() {
		if(MyPages.getPageObject("mmtLoginPage")==null) {
			MyPages.addObject("mmtLoginPage", new MMTLoginPage());
		}
		return (MMTLoginPage) MyPages.getPageObject("mmtLoginPage");
	}

}*/
