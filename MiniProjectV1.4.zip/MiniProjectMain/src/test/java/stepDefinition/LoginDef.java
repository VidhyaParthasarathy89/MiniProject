package stepDefinition;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.support.PageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import junit.framework.Assert;
import cucumber.api.java.en.*;
import pageObject.MMTHomePage;
import pageObject.MMTLoginPage;
import resourses.ExcelReader;
import resourses.Utilities;

public class LoginDef extends Utilities{
	MMTLoginPage login;
	
	@Given("^Open the browser and start application$")
	public void open_the_browser_and_start_application() throws Throwable {
		driver = initializeDriver();
		login = PageFactory.initElements(driver, MMTLoginPage.class);
	}
	
	@When("^I enter credentials and login$")
	public void i_enter_username_and_password(DataTable dt) throws Throwable {
		
		List<String> list = dt.asList(String.class);
		login.enterLoginDetails(list.get(0).toString(), list.get(1).toString());
		login.clickLoginButton();
	/*   login.clickLoginButton();
		List<String> list = dt.asList(String.class);
		login.getUsername().sendKeys(list.get(0));
		login.getContinue().click();
		System.out.println(list.get(1));
		login.getPassword().sendKeys(list.get(1)); */
	   
	}
	
	ExcelReader e = new ExcelReader();
	ArrayList<String> data;
	@When("^I enter valid credentials and login$")
	public void i_enter_valid_credentials_and_login() throws IOException {
		data = e.getData("Login successful for valid credentails", "LoginData");
		login.enterLoginDetails(data.get(1), data.get(2));
		login.clickLoginButton();
	    
	}

	@Then("^Login successful$")
	public void login_successful() throws IOException {
		driver.navigate().refresh();
		String actualText = login.loggedUserName().getText();
		System.out.println(actualText);
		Assert.assertEquals(expectedLoggedText(), actualText);
	    
	}

	@When("^I enter valid username invalid password and login$")
	public void i_enter_valid_username_invalid_password_and_login() throws IOException {
			data = e.getData("Error message displayed for invalid password", "LoginData");
			login.enterLoginDetails(data.get(1), data.get(2));
			login.clickLoginButton();
	}

	@Then("^Error message displayed$")
	public void error_message_displayed() throws IOException {
		String actualText = login.getWrongloginCredMsg().getText();
		System.out.println(actualText);
		Assert.assertEquals(getExpectedErrorMsg(), actualText);
		
	    
	}

	
}
